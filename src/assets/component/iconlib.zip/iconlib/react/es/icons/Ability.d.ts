declare const _default: import("../runtime").Icon;
export default _default;
